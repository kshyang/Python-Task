print ("BPP Pizza Price Calculator\n==========================\n")

def num_pizza():
    while True:
        pizza_only = (input("Enter the number of pizzas: "))
        try:
            pizza = int(pizza_only)
            if pizza < 1:#in case the value entered by the user is less then one for example 0, -1 and so on
                print("Please enter the amount of pizza you want\n")
                continue
            else:
                break
        except ValueError:
            print("Sorry the value you entered doesnt exist!\n")
            continue

    return pizza

def delivery():
    while True:
        charge = input("do you want the pizza to be delivered? (y/n): ")
        charge = charge.lower()
        if (charge == 'y') or (charge == 'n'):
            break
        else:
            print("Please enter a valid response!\n")
            continue
    return charge

def tuesday():
    while True:
        date = input("Is today tuesday? (y/n): ")
        date= date.lower()
        if (date == 'y') or (date == 'n'):
            break
        else:
            print("Please enter a valid response!\n")
            continue
    return date

def application():
    while True:
        app_used = input("Did the customer use the app (y/n): ")
        app_used= app_used.lower()
        if (app_used == 'y') or (app_used == 'n'):
            break
        else:
            print("Please enter a valid response!\n")
            continue

    return app_used

def calculate(pizza_amount, extra_charge, special_dis, application):
    price = 12
    delivery_cost = 2.5
    pizza_sum_price= pizza_amount * price
    total_delivery = 0.0
    total_price = 0

    if extra_charge=='y' and pizza_amount <= 5:
        total_delivery = delivery_cost
    if special_dis == "y":
        pizza_sum_price = pizza_sum_price - pizza_sum_price * 50 / 100 
    if application == "y":
        total_price = (pizza_sum_price + total_delivery )-( pizza_sum_price + total_delivery) * 25 /100 
        return total_price

    total_price = pizza_sum_price + total_delivery
    return total_price 

def display(overall_cost, pizza_amount, extra_charge, special_dis, application):
    print("\n----------Bill-----------\n")
    price = 12
    pizza_sum_price= pizza_amount * price
    total_delivery = 0.0
    delivery_cost = 2.5
    if extra_charge == "y" and pizza_amount <= 5:
        total_delivery = delivery_cost
    print("Delivery Charge: ", total_delivery)
    if special_dis == "y":
        t_pizza_sum_price = pizza_sum_price - (pizza_sum_price * 50 / 100)
        print("Tusday discount: ", t_pizza_sum_price)
    if application == "y" and special_dis == "y":
        print("App discount: ",(t_pizza_sum_price + total_delivery )-( t_pizza_sum_price + total_delivery) * 25 /100 )
    if application == "y" and special_dis == "n":
        print("App discount",pizza_sum_price - (( pizza_sum_price + total_delivery) * 25 /100 ))
 
    print(f"Total price: £{overall_cost:.2f}")

pizza_amount = num_pizza()
extra_charge = delivery()
special_dis = tuesday()
app_requirement = application()
overall_cost = calculate(pizza_amount, extra_charge, special_dis, app_requirement)
display(overall_cost, pizza_amount, extra_charge, special_dis, app_requirement)