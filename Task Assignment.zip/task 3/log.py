import getpass
import codecs
pass_file = "passwd.txt"

def log_in():
    # to log into the user file
    with open(pass_file, 'r') as file:
        make_good = file.readlines()

    username = input("Enter your username: ")
    password = getpass.getpass("Enter your password: ")
    en_password = codecs.encode(password, "rot13")
    de_password = codecs.encode(password, "rot13")

    for i in make_good:
        name = i.strip().split(':')[0]
        passwd = i.strip().split(':')[2]

        found = False

        if username == name:
            if en_password == passwd:
                found = True
                print ("you have logged in successfully")
                break
            
    if found==False:
        print("Sorry this user doesnot exist")

    return username, password, en_password, de_password        
