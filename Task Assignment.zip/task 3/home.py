import user_add
import delete
import log
import ch_pass
import sys

def main():

    while True:
        print("\nChoose the service you want:")
        print("'adduser' - Create Account")
        print("'login' Log In")
        print("'passwd' - Change Your Password")
        print("'deluser' - Delete User Profile")
        print("'exit' - Exit System")

        choice = None
        choice = input("Enter your choice: ")

        if choice == 'login':
            log.log_in()
        elif choice == 'adduser':
            user_add.adduser()
        elif choice == 'passwd':
            ch_pass.change_pass()
        elif choice == 'deluser':
            delete.del_user()
        elif choice == 'exit':
            print("Thank you for visiting")
            break
        else:
            print("Sorry please enter your choice!")


main()            
