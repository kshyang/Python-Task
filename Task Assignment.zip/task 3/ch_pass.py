import getpass
import codecs
pass_file = "passwd.txt"

def change_pass():
    #to change the password of user
    line_number = 0
    found = False
    make_good = ""
    new_password = ''
    confirmation = ''
    new_line = ""
    with open(pass_file, 'r') as file:
        make_good = file.readlines()
    
        username = input("Enter your username: ")
        password = getpass.getpass("Enter your password: ")#cant see me
        password = codecs.decode(password, "rot13")#cant read me

        for n,i in enumerate(make_good, start=1):
            name = i.strip().split(':')[0]
            rname = i.strip().split(':')[1]
            passwd = i.strip().split(':')[2]

            if username == name:
                if password == passwd:
                    found = True
                    new_password = getpass.getpass("Enter the new password for your account: ")
                    confirmation = getpass.getpass("Re-Enter your new password: ")
                    en_password = codecs.encode(confirmation, "rot13")
                    if new_password != confirmation:
                        print("Sorry your new password doesnot match eachother !")
                    new_line= f"{username}:{rname}:{en_password}\n"
                    make_good.append(new_line)
                    line_number = n
                    print("You have successfully changed your password !")
                    break

    with open('passwd.txt', 'a') as file: 
        file.write(new_line)
    
    # Write all lines back to the file except the line to delete
    with open('passwd.txt', 'w') as file:
        for i, line in enumerate(make_good, start=1):
            if i != line_number:
                file.write(line) 

    if found == False:
        print("Please Enter a Valid Username and password!!")
        return username, password, new_password, confirmation
    
