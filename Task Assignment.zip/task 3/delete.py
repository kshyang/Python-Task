import getpass
import codecs
pass_file = "passwd.txt"

def del_user():
    # to delete the existing user
    with open(pass_file, 'r') as file:
        make_good = file.readlines()

    username = input("Enter your username: ")
    password = getpass.getpass("Enter your password: ")#cant see me
    en_password = codecs.encode(password, "rot13")#cant read me
    de_password = codecs.decode(password, "rot13")

    for n,i in enumerate(make_good):
        name = i.strip().split(':')[0]

        found = False

        if username == name:
            del make_good[n]
            print("you have successfully deleted your account !")
            break

    if not found:
        print("Not found")

    with open(pass_file, "w") as file:
        file.writelines(make_good)

    return username, password, en_password, de_password     
        