import getpass
import codecs
pass_file = "passwd.txt"

def adduser():
    # to add new user create their profilio and create their username
    with open(pass_file, 'r') as file:
        make_good = file.readlines()
        username = input("Enter your username: ")
        real_name = input("Enter real name: ")
        password = getpass.getpass("Enter your password: ")
        password = codecs.encode(password, "rot13")


    for i in make_good:
        name = i.strip().split(':')[0]
        if username == name:
            print("sorry this username is already taken please choose another unique username\n")
            adduser()

    make_good.append(f"{username}:{real_name}:{password}\n")
    
    print("You have successfully created an account !")

    with open(pass_file, "w") as file:
        file.writelines(make_good)

    return username,real_name,password   


